# FAZON TR-1 Site

This is the official release of the FAZON TR-1 layer website.

- Language: English
- Included: Glossary, Pulses TR-1, FNFT Access Gateway
- License: CC BY 4.0