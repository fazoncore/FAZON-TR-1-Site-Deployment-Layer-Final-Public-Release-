## Johnson Glossary (EN)

- **FNFT**: Formed Non-Fungible Token
- **Pulse**: Semantic impulse trigger
- **STPE**: Semantic Transformation Phase Engine
...