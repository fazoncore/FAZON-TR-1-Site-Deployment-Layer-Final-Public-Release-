### Pulses TR-1

- PULSE_001: Entry Trigger
- PULSE_002: Phase Sync
- PULSE_003: Semantic Gate
...